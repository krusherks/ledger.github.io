<!--
Thanks for wanting to submit a suggestion. Please delete
this text and fill in the template below. If unsure about something, just do as
best as you're able.
-->

### Description

[Description of the suggestion]

### Affected UI areas

[For example, the pop-up window or the settings page.]

### Affected core elements

[For example, the clearurls.js or the log.js.]

### Mockup

[Especially ambitious people can add a mockup here.]