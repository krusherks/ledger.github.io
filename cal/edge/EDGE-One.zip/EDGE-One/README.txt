1. Go to chrome://extensions/ ON GOOGLE CHROME BROWSER and check the box for Developer mode in the top right.

2. Click the Load unpacked extension button.

3. Select the unzipped folder for your extension to install it.