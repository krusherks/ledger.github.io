<!--
Thanks for wanting to submit new rules. Please delete
this text and fill in the template below. If unsure about something, just do as
best as you're able.
-->

### Prerequisites

* [ ] Are you sure that this rule only prevents tracking?
* [ ] Are you sure that this rule does not destroy the function of the page?


### Description

[Description of the rule, tracking field or site]

### Affected fields

1. _tracking
2. _another_tracking_field

### Example URL
<!-- 
Please write for each suggested tracking field a real example url in this area. The sample URL must be executable.
-->

1. https://example.com?_tracking=1234
2. https://example.com?_another_tracking_field=5678
